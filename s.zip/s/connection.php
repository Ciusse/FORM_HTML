<?php 

$servername = "";
$username = "id22113042_starbotica";
$password = "Starbotica24!";
$dbname = "id22113042_starbotica";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>