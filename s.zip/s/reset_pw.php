<html>
<head>
<title>Reset password</title>
<link href="style.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
    <style>
        /* Stili per gli input */
input[type="email"],
input[type="password"] {
    border-radius: 20px; /* Bordi arrotondati */
    padding: 8px; /* Spazio interno */
    border: 2px solid #483d8b; /* Colore del bordo */
    background-color: #ffd700; /* Colore di sfondo */
    color: #008000; /* Colore del testo */
    font-size: 16px; /* Dimensione del testo */
    transition: all 0.3s; /* Animazione delle transizioni */
}

/* Stile al passaggio del mouse */
input[type="email"]:hover,
input[type="password"]:hover {
    border-color: #ff8c00; /* Cambia il colore del bordo al passaggio del mouse */
}

/* Stile al focus */
input[type="email"]:focus,
input[type="password"]:focus {
    outline: none; /* Rimuove l'outline predefinito */
    border-color: #6a5acd; /* Cambia il colore del bordo al focus */
    box-shadow: 0 0 5px #6a5acd; /* Aggiunge una leggera ombra */
}
    </style>
</head>
<body>
    <div class="container">
  <div style="border:1px solid white; padding:2px; padding-left: 17px; padding-right: 17px; padding-bottom: 17px;">
    
    <form action="check.php" method="post" required>
    <center>
    <h1>MODIFICA LA PASSWORD INSERENDO I DATI CORRETTI</h1>
    Email: <input type="email" name="email" required><br><br>
    Nuova password: <input type="password" name="password" required><br><br>
    <input  class = "bottone" type = "submit" onclick="return confirm('Vuoi modificare veramente?')">

    </form>
    <br><br>
    <form action="index.php">
            <button class="bottone" type="submit">Torna al login</button>
        </form>
    </div></div>
    </center>
</body>
</html>
