<?php
include 'connection.php';

$email = $_POST["mail"];
//$password = md5($_POST["password"]);
$password =$_POST["password"];
// Query per l'inserimento dei dati nella tabella Utenti
$sql = "INSERT INTO Utenti (email, password) 
        VALUES ('$email', '$password')";

if ($conn->query($sql) === TRUE) {
    // Ottiene l'ID utente appena inserito
    $id_utente = $conn->insert_id;

    // Reindirizza l'utente alla pagina di login dopo la registrazione
    echo '<script>setTimeout(function(){ location.replace("index.php"); }, 500);</script>';
} else {
    echo "Errore durante l'inserimento dei dati: " . $conn->error;
}

// Chiude la connessione al database
$conn->close();
?>
