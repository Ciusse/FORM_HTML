<!DOCTYPE html>
<html>
<head>
    <link href="style.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
    <title>Delete</title>
    <style>
        /* Stili per gli input */
        input[type="number"] {
            border-radius: 20px; /* Bordi arrotondati */
            padding: 8px; /* Spazio interno */
            border: 2px solid #483d8b; /* Colore del bordo */
            background-color: #ffd700; /* Colore di sfondo */
            color: #008000; /* Colore del testo */
            font-size: 16px; /* Dimensione del testo */
            transition: all 0.3s; /* Animazione delle transizioni */
        }

        /* Stile al passaggio del mouse */
        input[type="number"]:hover {
            border-color: #ff8c00; /* Cambia il colore del bordo al passaggio del mouse */
        }

        /* Stile al focus */
        input[type="number"]:focus {
            outline: none; /* Rimuove l'outline predefinito */
            border-color: #6a5acd; /* Cambia il colore del bordo al focus */
            box-shadow: 0 0 5px #6a5acd; /* Aggiunge una leggera ombra */
        }
    </style>
</head>

<body>
<div style="border:2px solid white; padding-top:15px; padding-left: 20px; padding-right: 20px; padding-bottom: 7px;">
    <form action="menu.php">
        <center>
            <button class="bottone" type="submit">Torna al menu'</button>
        </center>
    </form>

    <form action="" method="POST">
        <h1>Inserisci un utente da eliminare</h1>
        <center>
            <input type="number" name="pk">
            <input class="bottone" type="submit" onclick="return confirm('Vuoi eliminare veramente?')">
            
        </center>
    </form>
<?php
include 'connection.php';

if (isset($_POST['pk'])) {
    $id = $_POST['pk'];

    // Verifica se l'utente esiste nella tabella Utenti
    $sql_utente = "SELECT * FROM Utenti WHERE id_utente = $id";
    $result_utente = $conn->query($sql_utente);

    if ($result_utente->num_rows > 0) {
        // Elimina l'utente dalla tabella Utenti
        $sql_delete_utente = "DELETE FROM Utenti WHERE id_utente = $id";
        if ($conn->query($sql_delete_utente) === TRUE) {
            // Aggiorna manualmente gli ID
            $sql_update_ids = "SET @num := 0; UPDATE Utenti SET id_utente = @num := (@num+1); ALTER TABLE Utenti AUTO_INCREMENT = 1;";
            if ($conn->multi_query($sql_update_ids) === TRUE) {
                echo "<br><span>Utente eliminato correttamente</span>";
            } else {
                echo "<br><span>Error during ID update</span>" . $conn->error;
            }
        } else {
            echo "<br><span>Error</span>" . $conn->error;
        }
    } else {
        echo "<div style='text-align: center;'><span>Utente non valido</span></div>";
    }
} else{
    echo "<div style='text-align: center;'><span>Inserire un ID valido</span></div>";
}
?>
<center>
    <form action="tabella_delete.php">
                <button class="bottone" type="submit">Vedi utenti</button>
            </form></center>
</div>
</body>
</html>
