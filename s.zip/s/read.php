<html>
<head>
    <link href="style.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
    <title>Read</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 1rem;
            color: #fff;
            font-size: 0.9em;
            font-family: Arial, sans-serif;
            border: 2px solid white;
        }
        table th {
            background-color: black;
            color: white;
            font-weight: bold;
            padding: 8px;
            text-align: left;
            border: 2px solid white;
        }
        table td {
            padding: 8px;
            text-align: left;
            vertical-align: top;
            border: 2px solid white;
        }
        table tr:hover {
            background-color: #ddd;
            font-weight: bold;
            color: #000;
        }
        table th,
        table td {
            background-color: black;
            color: #fff;
        }
        /* Stili per gli input */
input[type="number"]{
    border-radius: 20px; /* Bordi arrotondati */
    padding: 8px; /* Spazio interno */
    border: 2px solid #483d8b; /* Colore del bordo */
    background-color: #ffd700; /* Colore di sfondo */
    color: #008000; /* Colore del testo */
    font-size: 16px; /* Dimensione del testo */
    transition: all 0.3s; /* Animazione delle transizioni */
}

/* Stile al passaggio del mouse */
input[type="number"]:hover {
    border-color: #ff8c00; /* Cambia il colore del bordo al passaggio del mouse */
}

/* Stile al focus */
input[type="number"]:focus {
    outline: none; /* Rimuove l'outline predefinito */
    border-color: #6a5acd; /* Cambia il colore del bordo al focus */
    box-shadow: 0 0 5px #6a5acd; /* Aggiunge una leggera ombra */
}
       .container {
    border: 2px solid white;
    padding: 15px 20px;
    margin: 0 auto;
    width: max-content; /* Imposta la larghezza al massimo contenuto */
    text-align: center;
    overflow-x: auto; /* Aggiungi uno scroll orizzontale se la larghezza supera quella del contenitore */
}
        .bottone {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="menu.php">
            <button class="bottone" type="submit">Torna al menu</button>
        </form>
        <form action="" method="POST">
            <h1>Inserisci un utente da visualizzare</h1>
            <input type="number" name="pk" required>
        
            <input class="bottone" type="submit">
        </form>
       
        <?php include 'connection.php';
        if(isset($_POST["pk"]))
        {
            $id = $_POST["pk"];
            if(isset($id))
            {
                $sql = "SELECT * FROM Utenti WHERE id_utente = ".$id;
                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0)
                {
                    $row = mysqli_fetch_assoc($result);
                    ?>
                    <table>
                        <tr>
                            <th>ID Utente</th>
                            <td><?php echo $row['id_utente']; ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?php echo $row['email']; ?></td>
                        </tr>
                        <tr>
                            <th>Password</th>
                            <td><?php echo $row['password']; ?></td>
                        </tr>
                    </table>
                    <?php
                } else {
                    echo "Il record ricercato non esiste";
                }
            }
        }
        ?>
         <form action="tabella_read.php">
            <button class="bottone" type="submit">Vedi utenti</button>
        </form>
    </div>
</body>
</html>