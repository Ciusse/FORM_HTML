<?php
    session_start();
    session_destroy();
    echo '<script>setTimeout(function(){ location.replace("index.php"); }, 2000);</script>';
    //header("refresh:1.2;url=index.php");
?>
<html>
<head>
    <title>Logout</title>
    <link href="style.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
</head>
<body>
    <h2>Grazie per aver visitato il nostro sito:)</h2>
    <div class="loading">
        <div class="loading-bar"></div>
        <div class="loading-bar"></div>
        <div class="loading-bar"></div>
        <div class="loading-bar"></div>
    </div>
</body>
</html>