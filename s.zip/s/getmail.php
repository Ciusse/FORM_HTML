<?php
include 'connection.php';

// get the q parameter from URL
if(isset($_REQUEST["q"]))
{
$q = $_REQUEST["q"];
}
$hint = "<span style='color: #00ff00; font-weight: bold;'>Email available</span><br>";;
    //SELEZIONO LA TABELLA UTENTI
    $sql = "SELECT email FROM Utenti";
    $result = $conn->query($sql);
    
      if ($result->num_rows > 0) {
          // output data of each row
          
          while($row = $result->fetch_assoc()) {
           if($q==$row["email"])
            {
                $hint = "<span style='color: #ff0000; font-weight: bold;'>Email already in use</span><br>";;
            }
            
        }
    }

        print($hint);
          
?>