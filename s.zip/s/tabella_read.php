<!DOCTYPE html>
<html>
<head>
    <title>Lista utenti</title>
    <link href="style.css" rel="stylesheet" type="text/css">
</head>
<body>
    <div style="border:2px solid white; padding-top:15px; padding-left: 20px; padding-right: 20px; padding-bottom: 7px; text-align: center">
        <h2>Lista utenti</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Email</th>
                    <th>Password</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    include "connection.php";

                    // Query per recuperare la lista degli utenti
                    $sql = "SELECT * FROM Utenti";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Stampa dei risultati in una tabella
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["id_utente"] . "</td>";
                            echo "<td>" . $row["email"] . "</td>";
                            echo "<td>" . $row["password"] . "</td>"; // Cambiato da input di tipo password a text
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>Nessun utente trovato</td></tr>";
                    }

                    $conn->close();
                ?>
            </tbody>
        </table>
        <center>
            <br>
            <br>
            <form action="read.php">
                <button class="bottone" type="submit">Ritorna alla read</button>
            </form>
            <br>
        </center>
    </div>
</body>
</html>
