<html>
    <head>
    <link href="style.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
    <title>Menu</title>
    <style>
     .container {
    border: 2px solid white;
    padding: 15px 20px;
    margin: 0 auto;
    width: max-content; /* Imposta la larghezza al massimo contenuto */
    text-align: center;
    overflow-x: auto; /* Aggiungi uno scroll orizzontale se la larghezza supera quella del contenitore */
}
        .bottone {
            margin-top: 10px;
        }
    </style>
    </head>
    <div style="display: flex; align-items:center; width:20%; justify-content:space-evenly; margin-left:70%">
    <div style="margin-right: 1px;">
        <img src="users.png" width="32" height="32">
    </div>
    <h4>Benvenuto</h4>
  </div>
  <center>
      <div class="container">
        <h1> MENU' CRUD</h1>
        <form action = "read.php" >
            <button  class = "bottone" type = "submit">
                Read
            </button>
        </form>

        <form action = "delete.php" >
            <button  class= "bottone" type = "submit">
                Delete
            </button>
        </form>

<form action = "index.php" >
            <button  class= "bottone" type = "submit">
                Logout
            </button>
        </form>
   
</center>

</div>
</body>
</html>