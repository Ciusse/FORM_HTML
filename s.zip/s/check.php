<html>
<head>
  <title>Check</title>
  <link href="style.css" rel="stylesheet" type="text/css">
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
</head>
<body>
  <?php
    include 'connection.php'; 

    // Verifica della connessione
    if (!$conn) {
      die("Errore di connessione: " . mysqli_connect_error());
    } else {
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Recupero dell'email
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        // Recupero della password inserita
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        // Verifica se l'email esiste nel database
        $sql = "SELECT * FROM Utenti WHERE email = '$email'";
        $result = mysqli_query($conn, $sql);
        $count = mysqli_num_rows($result);

        if ($count == 1) {
          // Crittografia della password
          $password = md5($password);

          // Aggiornamento della password nel database
          $update_query = "UPDATE Utenti SET password = '$password' WHERE email = '$email'";
          if (mysqli_query($conn, $update_query)) {
            echo '<h2>La password è stata modificata con successo!</h2>';
            echo '<div class="loading">';
            echo '  <div class="loading-bar"></div>';
            echo '  <div class="loading-bar"></div>';
            echo '  <div class="loading-bar"></div>';
            echo '  <div class="loading-bar"></div>';
            echo '</div>';
            echo '<script>setTimeout(function(){ location.replace("index.php"); }, 2000);</script>';
          } else {
            echo "Errore nell'aggiornamento della password: " . mysqli_error($conn);
          }
        } else {
          echo "Email non trovata.";
        }
      }
    }
    // Chiusura della connessione
    mysqli_close($conn);
  ?>
</body>
</html>
