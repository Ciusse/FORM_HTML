<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link href="style.css" rel="stylesheet" type="text/css">
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
 <style>
     img.eye-icon {
        width: 30px; /* Imposta la larghezza desiderata */
        height: auto; /* Altezza automatica proporzionale alla larghezza */
        cursor: pointer; /* Cambia il cursore al passaggio del mouse */
        position: absolute; /* Posizionamento assoluto */
        bottom: 456px; 
        left:950px;
    }
    /* Stili per gli input */
input[type="email"],
input[type="password"] {
    border-radius: 20px; /* Bordi arrotondati */
    padding: 8px; /* Spazio interno */
    border: 2px solid #483d8b; /* Colore del bordo */
    background-color: #ffd700; /* Colore di sfondo */
    color: #008000; /* Colore del testo */
    font-size: 16px; /* Dimensione del testo */
    transition: all 0.3s; /* Animazione delle transizioni */
}

/* Stile al passaggio del mouse */
input[type="email"]:hover,
input[type="password"]:hover {
    border-color: #ff8c00; /* Cambia il colore del bordo al passaggio del mouse */
}

/* Stile al focus */
input[type="email"]:focus,
input[type="password"]:focus {
    outline: none; /* Rimuove l'outline predefinito */
    border-color: #6a5acd; /* Cambia il colore del bordo al focus */
    box-shadow: 0 0 5px #6a5acd; /* Aggiunge una leggera ombra */
}
 </style>
  <script>
    function showPassword() {
      var x = document.getElementById("password");
      if (x.type === "password") {
        x.type = "text";
      } else {
        x.type = "password";
      }
    }
  </script>
</head>
<body>
<div style="border:1px solid white; padding:2px; padding-left: 17px; padding-right: 17px; padding-bottom: 17px;">
  <form method="post" action="" id="form" required>
    <center>
      <h1> Login per accedere al menù CRUD</h1>
      <input type="email" name="email" required>
      <input type="password" id="password" name="password" style="border-radius: 20px; padding: 8px; border: 2px solid #483d8b; background-color: #ffd700; color: #008000; font-size: 16px; transition: all 0.3s;" required>

      <img class="eye-icon" src="eye.png" alt="Password" onclick="showPassword()" ><br> 
      <br><button class="bottone" type="submit">
        Login
      </button>
      <button class="bottone" type="button" onclick="location.href='reset_pw.php'">
      Reset password
    </button>
      
    </center>
    <br>
    <hr style="width: 70%;">
  </form>
  <hr style="width: 50%;">

  <hr style="width: 70%;">
  <center>
    <br>
    
    <h2>Per registrarti clicca il bottone qui sotto</h2>
    <button class="bottone" type="button" onclick="location.href='register.php'">
      Registrati
    </button>
  </center>
  
  <?php
    // Include il file di connessione al database
    include 'connection.php';

    // Controlla se sono stati inviati i dati del form
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      // Controlla se sia stata fornita una email e una password
      if(empty($_POST['email']) || empty($_POST['password'])) {
        echo '<script>alert("Inserisci email e password");</script>';
      } else {
        // Prendi email e password dal form
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Hasha la password
        $hashed_password = md5($password);

        // Prepara la query per selezionare l'utente con l'email e la password corrispondenti
        $sql = "SELECT * FROM Utenti WHERE email=? AND password=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $email, $hashed_password);
        $stmt->execute();
        $result = $stmt->get_result();

        // Controlla se esiste un utente con quelle credenziali
        if ($result->num_rows == 1) {
          // Reindirizza l'utente alla pagina protetta
          echo '<script>location.replace("menu.php");</script>';
          exit;
        } else {
          // Credenziali di accesso errate
          echo '<br>';
          echo 'Email o password non presenti nel database';
        }
      }
    }
  ?>
</div>
</body>
</html>