<!DOCTYPE html>
<html>
<head>
    <title>Sign in</title>
    <link href="style.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
    <style>
        .container {
            border: 2px solid white;
            padding: 15px 20px;
            margin: 0 auto;
            width: 300px;
            text-align: center;
        }
        .bottone {
            margin-top: 10px;
        }
        /* Stili per gli input */
input[type="email"],
input[type="text"] {
    border-radius: 20px; /* Bordi arrotondati */
    padding: 8px; /* Spazio interno */
    border: 2px solid #483d8b; /* Colore del bordo */
    background-color: #ffd700; /* Colore di sfondo */
    color: #008000; /* Colore del testo */
    font-size: 16px; /* Dimensione del testo */
    transition: all 0.3s; /* Animazione delle transizioni */
}

/* Stile al passaggio del mouse */
input[type="email"]:hover,
input[type="text"]:hover {
    border-color: #ff8c00; /* Cambia il colore del bordo al passaggio del mouse */
}

/* Stile al focus */
input[type="email"]:focus,
input[type="text"]:focus {
    outline: none; /* Rimuove l'outline predefinito */
    border-color: #6a5acd; /* Cambia il colore del bordo al focus */
    box-shadow: 0 0 5px #6a5acd; /* Aggiunge una leggera ombra */
}
    </style>
</head>
<body>
    <div class="container">
        <button class="bottone" type="submit" onclick="location.href='index.php'">Torna al login</button>
        <br><br><br>
        <form action="output.php" onsubmit="return validateForm()" method="post" required>
            Email: <input type="email" name="mail" onkeyup="showUser(this.value)" required><br>
            <br><br>
            <span id="txtHint" name="txtHint" value=""></span><br>
            Password: <input type="text" name="password" required><br><br> <!-- Modificato da password a text -->
            <br><br>
            <input class="bottone" type="submit">
        </form>
    </div>
</body>
<script>
    //Funzioni per controllo email e form
    let x ="";
    function showUser(str) {
        if (str=="") {
            document.getElementById("txtHint").innerHTML="";
            return;
        }
        var xmlhttp=new XMLHttpRequest();
        xmlhttp.onreadystatechange=function() {
            if (this.readyState==4 && this.status==200) {
                x=this.responseText;
                x=x.slice(4);
                document.getElementById("txtHint").innerHTML=this.responseText;
            }
        }
        xmlhttp.open("GET","getmail.php?q="+str,true);
        xmlhttp.send();
    }

    function validateForm() {
        if(x=="Email already in use") {
            alert("Insert an available email");
            return false;
        } else {
            return true;
        }
    }
</script>
</html>